
import React from 'react';
import { SloganItem } from './SloganItem';

interface SloganListProps {
  slogans: string[];
}

export const SloganList: React.FC<SloganListProps> = ({ slogans }) => {
  if (slogans.length === 0) {
    return null; 
  }

  return (
    <div className="space-y-4">
      {slogans.map((slogan, index) => (
        <SloganItem key={index} slogan={slogan} />
      ))}
    </div>
  );
};
