
import React from 'react';

interface InputAreaProps {
  value: string;
  onChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder?: string;
}

export const InputArea: React.FC<InputAreaProps> = ({ value, onChange, placeholder }) => {
  return (
    <div>
      <label htmlFor="description" className="block text-lg font-medium text-sky-300 mb-2">
        説明入力:
      </label>
      <textarea
        id="description"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        rows={5}
        className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 text-slate-100 placeholder-slate-400 transition-colors duration-150"
      />
      <p className="mt-1 text-sm text-slate-400">
        できるだけ詳しく説明すると、より的確なキャッチコピーが生成されやすくなります。
      </p>
    </div>
  );
};
