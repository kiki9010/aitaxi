
import React from 'react';
import { SloganSettings, TONE_OPTIONS, AUDIENCE_OPTIONS, ToneOption, AudienceOption } from '../types';
import { MIN_SLOGANS, MAX_SLOGANS } from '../constants';

interface SettingsPanelProps {
  settings: SloganSettings;
  onSettingsChange: (newSettings: SloganSettings) => void;
}

const SelectInput: React.FC<{
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: readonly string[];
}> = ({ id, label, value, onChange, options }) => (
  <div className="flex-1 min-w-[150px]">
    <label htmlFor={id} className="block text-sm font-medium text-sky-300 mb-1">
      {label}:
    </label>
    <select
      id={id}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full p-2.5 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 text-slate-100"
    >
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  </div>
);


export const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onSettingsChange }) => {
  const handleNumSlogansChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let num = parseInt(e.target.value, 10);
    if (isNaN(num)) num = MIN_SLOGANS;
    num = Math.max(MIN_SLOGANS, Math.min(MAX_SLOGANS, num));
    onSettingsChange({ ...settings, numSlogans: num });
  };

  return (
    <div className="space-y-4 p-4 bg-slate-700/50 rounded-lg border border-slate-600">
      <h3 className="text-md font-semibold text-sky-400 mb-3 border-b border-slate-600 pb-2">オプション設定</h3>
      <div className="flex flex-col sm:flex-row gap-4">
        <SelectInput
          id="tone"
          label="トーン"
          value={settings.tone}
          onChange={(val) => onSettingsChange({ ...settings, tone: val as ToneOption })}
          options={TONE_OPTIONS}
        />
        <SelectInput
          id="targetAudience"
          label="ターゲット"
          value={settings.targetAudience}
          onChange={(val) => onSettingsChange({ ...settings, targetAudience: val as AudienceOption })}
          options={AUDIENCE_OPTIONS}
        />
        <div className="flex-1 min-w-[150px]">
          <label htmlFor="numSlogans" className="block text-sm font-medium text-sky-300 mb-1">
            生成数:
          </label>
          <input
            type="number"
            id="numSlogans"
            value={settings.numSlogans}
            onChange={handleNumSlogansChange}
            min={MIN_SLOGANS}
            max={MAX_SLOGANS}
            className="w-full p-2.5 bg-slate-700 border border-slate-600 rounded-md shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 text-slate-100"
          />
        </div>
      </div>
    </div>
  );
};

