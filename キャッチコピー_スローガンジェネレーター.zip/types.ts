
export interface SloganSettings {
  numSlogans: number;
  tone: string;
  targetAudience: string;
}

export interface GeneratedSlogansResponse {
  slogans: string[];
}

export type ToneOption = '指定なし' | 'ユーモラス' | '真面目' | '革新的' | 'クラシック' | '感動的' | '親しみやすい' | '高級志向' | 'エネルギッシュ';
export type AudienceOption = '指定なし' | '一般' | '若者' | 'ビジネスプロフェッショナル' | 'ファミリー' | '高齢者' | '女性' | '男性' | 'ニッチ市場';

export const TONE_OPTIONS: ToneOption[] = ['指定なし', 'ユーモラス', '真面目', '革新的', 'クラシック', '感動的', '親しみやすい', '高級志向', 'エネルギッシュ'];
export const AUDIENCE_OPTIONS: AudienceOption[] = ['指定なし', '一般', '若者', 'ビジネスプロフェッショナル', 'ファミリー', '高齢者', '女性', '男性', 'ニッチ市場'];

// This type can be used for Grounding Chunks if you implement search grounding
export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
  retrievedContext?: {
    uri: string;
    title: string;
  };
  // Add other possible grounding sources if needed
}
