
import { SloganSettings } from './types';

export const DEFAULT_SLOGAN_SETTINGS: SloganSettings = {
  numSlogans: 5,
  tone: '指定なし',
  targetAudience: '指定なし',
};

export const MIN_SLOGANS = 1;
export const MAX_SLOGANS = 10;

export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';
