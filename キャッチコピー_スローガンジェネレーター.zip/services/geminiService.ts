
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SloganSettings, GeneratedSlogansResponse } from '../types';
import { GEMINI_MODEL_NAME } from '../constants';

const parseJsonSafely = <T,>(jsonString: string): T | null => {
  let cleanJsonString = jsonString.trim();
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = cleanJsonString.match(fenceRegex);
  if (match && match[1]) {
    cleanJsonString = match[1].trim();
  }
  try {
    return JSON.parse(cleanJsonString) as T;
  } catch (error) {
    console.error("Failed to parse JSON:", error, "Original string:", jsonString);
    throw new Error(`レスポンスのJSON解析に失敗しました。受信データ: ${jsonString.substring(0,100)}...`);
  }
};

export const generateSlogans = async (
  description: string,
  settings: SloganSettings
): Promise<string[]> => {
  if (!process.env.API_KEY) {
    throw new Error("APIキーが設定されていません。環境変数 `API_KEY` を設定してください。");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  let prompt = `あなたはプロのコピーライターです。以下の情報に基づいて、製品、サービス、ビジネス、またはキャンペーンのためのキャッチコピー/スローガンを${settings.numSlogans}個生成してください。

製品/サービス/ビジネス/キャンペーンの説明:
${description}
`;

  if (settings.tone !== '指定なし') {
    prompt += `\n希望するトーン: ${settings.tone}`;
  }
  if (settings.targetAudience !== '指定なし') {
    prompt += `\nターゲットオーディエンス: ${settings.targetAudience}`;
  }

  prompt += `

各スローガンはユニークで、簡潔かつ魅力的であるべきです。
結果は以下のJSON形式で返してください:
{
  "slogans": [
    "スローガン1",
    "スローガン2",
    ...
  ]
}`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.8, // Slightly higher for more creative/varied slogans
        topP: 0.95,
        topK: 40,
      }
    });

    const responseText = response.text;
    if (!responseText) {
        throw new Error("APIから空のレスポンスが返されました。");
    }
    
    const parsedData = parseJsonSafely<GeneratedSlogansResponse>(responseText);

    if (parsedData && Array.isArray(parsedData.slogans)) {
      return parsedData.slogans;
    } else {
      console.error("予期しないJSON構造:", parsedData, "Original text:", responseText);
      throw new Error("APIからのレスポンス形式が正しくありません。期待したスローガンの配列が見つかりませんでした。");
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    if (error instanceof Error) {
        throw new Error(`Gemini APIとの通信に失敗しました: ${error.message}`);
    }
    throw new Error("Gemini APIとの通信中に不明なエラーが発生しました。");
  }
};
