
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { SettingsPanel } from './components/SettingsPanel';
import { SloganSettings } from './types'; // Corrected: SloganSettings imported from './types'
import { InputArea } from './components/InputArea';
import { SloganList } from './components/SloganList';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { generateSlogans } from './services/geminiService';
import { DEFAULT_SLOGAN_SETTINGS } from './constants';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  const [description, setDescription] = useState<string>('');
  const [settings, setSettings] = useState<SloganSettings>(DEFAULT_SLOGAN_SETTINGS);
  const [generatedSlogans, setGeneratedSlogans] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateSlogans = useCallback(async () => {
    if (!description.trim()) {
      setError('製品やサービスの説明を入力してください。');
      return;
    }
    
    // Basic check for API_KEY
    if (!process.env.API_KEY) {
        setError('APIキーが設定されていません。環境変数 `API_KEY` を設定してください。');
        setIsLoading(false);
        return;
    }


    setIsLoading(true);
    setError(null);
    setGeneratedSlogans([]);

    try {
      const slogans = await generateSlogans(description, settings);
      setGeneratedSlogans(slogans);
    } catch (err) {
      if (err instanceof Error) {
        setError(`スローガンの生成に失敗しました: ${err.message}`);
      } else {
        setError('スローガンの生成中に不明なエラーが発生しました。');
      }
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [description, settings]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-between p-4 sm:p-6 md:p-8 selection:bg-sky-500 selection:text-white bg-slate-900">
      <main className="container mx-auto max-w-3xl w-full space-y-8">
        <Header />
        
        <div className="bg-slate-800 shadow-2xl rounded-xl p-6 md:p-8 space-y-6">
          <InputArea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="例: 環境に優しい素材を使った新しいスニーカーブランド。若者向けで、都市部でのアクティブなライフスタイルをサポートします。"
          />
          
          <SettingsPanel settings={settings} onSettingsChange={setSettings} />

          <button
            onClick={handleGenerateSlogans}
            disabled={isLoading}
            className="w-full bg-sky-600 hover:bg-sky-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-opacity-50 flex items-center justify-center text-lg"
          >
            {isLoading ? (
              <>
                <LoadingSpinner size="sm" />
                <span className="ml-2">生成中...</span>
              </>
            ) : (
              'キャッチコピーを生成'
            )}
          </button>
        </div>

        {error && <ErrorMessage message={error} onClose={() => setError(null)} />}

        {generatedSlogans.length > 0 && (
          <div className="bg-slate-800 shadow-2xl rounded-xl p-6 md:p-8">
            <h2 className="text-2xl font-semibold text-sky-400 mb-6 text-center">生成されたキャッチコピー</h2>
            <SloganList slogans={generatedSlogans} />
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default App;
